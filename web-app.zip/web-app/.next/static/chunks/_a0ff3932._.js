(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c0cac578._.js",
  "static/chunks/06411_next_dist_compiled_react-dom_56d86008._.js",
  "static/chunks/06411_next_dist_compiled_next-devtools_index_1e0a9ffc.js",
  "static/chunks/06411_next_dist_compiled_6da5cead._.js",
  "static/chunks/06411_next_dist_client_a6e6c1b4._.js",
  "static/chunks/06411_next_dist_916e9179._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
